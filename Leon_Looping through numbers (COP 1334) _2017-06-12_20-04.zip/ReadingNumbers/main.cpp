#include <iostream>

using namespace std;

int main()
{

    int firstNum=0, secondNum=0;
    int sum=0,n,i;
    cin >> firstNum >> secondNum;
    while(firstNum>secondNum){
    cout<<"Please enter two numbers"<<endl;
    cin >> firstNum >> secondNum;}
      i=firstNum;
    while(i<=secondNum){
      //show i if odd

     if(i%2!=0){
        cout << i <<endl;
      }

       sum += i;
       i++;
                        }
      cout << sum <<endl;





    //make a loop

   // cout << i<< endl; //print all the odd numbers inside the loop
    //cout << sum << endl;  //print the sum
    return 0;
}
